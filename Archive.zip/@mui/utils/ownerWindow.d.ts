export default function ownerWindow(node: Node | undefined): Window;
