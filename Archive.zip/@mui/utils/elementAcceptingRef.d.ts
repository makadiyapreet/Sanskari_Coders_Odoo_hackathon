import PropTypes from 'prop-types';
declare const elementAcceptingRef: PropTypes.Requireable<unknown>;
export default elementAcceptingRef;
