import PropTypes from 'prop-types';
declare const _default: PropTypes.Validator<PropTypes.ReactComponentLike | null | undefined>;
export default _default;
