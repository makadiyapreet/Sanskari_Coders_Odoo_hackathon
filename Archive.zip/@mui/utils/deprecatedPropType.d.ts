export default function deprecatedPropType<T>(validator: T, reason: string): T;
