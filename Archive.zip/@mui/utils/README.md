# @mui/utils

Shared utilities used by MUI packages.
