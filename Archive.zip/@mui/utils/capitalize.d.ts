export default function capitalize(string: string): string;
