declare const visuallyHidden: import('react').CSSProperties;
export default visuallyHidden;
