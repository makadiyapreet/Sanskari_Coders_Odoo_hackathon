export function getTypeByValue(value: any): any;
declare function _default(props: any, propName: any, ...other: any[]): RangeError | null;
declare namespace _default {
    export { requiredInteger as isRequired };
}
export default _default;
declare function requiredInteger(props: any, propName: any, componentName: any, location: any): RangeError | null;
