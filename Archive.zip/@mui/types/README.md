# @mui/types

Utility types used by MUI.
