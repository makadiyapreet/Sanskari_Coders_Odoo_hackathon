function _instanceof(n, e) {
  return null != e && "undefined" != typeof Symbol && e[Symbol.hasInstance] ? !!e[Symbol.hasInstance](n) : n instanceof e;
}
module.exports = _instanceof, module.exports.__esModule = true, module.exports["default"] = module.exports;