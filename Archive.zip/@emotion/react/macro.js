module.exports = require('@emotion/babel-plugin').macros.core
