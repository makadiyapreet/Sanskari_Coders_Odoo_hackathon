export default function _throw(e) {
    throw e;
}