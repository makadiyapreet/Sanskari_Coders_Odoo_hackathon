export { __param as default } from 'tslib'
