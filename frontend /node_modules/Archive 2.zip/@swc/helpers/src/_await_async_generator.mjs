import AwaitValue from './_await_value.mjs';

export default function _awaitAsyncGenerator(value) {
  return new AwaitValue(value);
}
