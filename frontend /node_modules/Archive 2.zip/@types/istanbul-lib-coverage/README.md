# Installation
> `npm install --save @types/istanbul-lib-coverage`

# Summary
This package contains type definitions for istanbul-lib-coverage (https://istanbul.js.org).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/istanbul-lib-coverage.

### Additional Details
 * Last updated: Thu, 23 Dec 2021 23:34:53 GMT
 * Dependencies: none
 * Global values: none

# Credits
These definitions were written by [Jason Cheatham](https://github.com/jason0x43).
