# Installation
> `npm install --save @types/aria-query`

# Summary
This package contains type definitions for aria-query (https://github.com/A11yance/aria-query#readme).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/aria-query.

### Additional Details
 * Last updated: Thu, 27 Oct 2022 11:02:43 GMT
 * Dependencies: none
 * Global values: none

# Credits
These definitions were written by [Sebastian Silbermann](https://github.com/eps1lon).
