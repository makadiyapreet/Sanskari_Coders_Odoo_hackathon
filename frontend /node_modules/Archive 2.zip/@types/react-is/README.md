# Installation
> `npm install --save @types/react-is`

# Summary
This package contains type definitions for react-is (https://reactjs.org/).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/react-is.

### Additional Details
 * Last updated: Thu, 21 Oct 2021 23:01:39 GMT
 * Dependencies: [@types/react](https://npmjs.com/package/@types/react)
 * Global values: `ReactIs`

# Credits
These definitions were written by [Avi Vahl](https://github.com/AviVahl), [Christian Chown](https://github.com/christianchown), and [Sebastian Silbermann](https://github.com/eps1lon).
