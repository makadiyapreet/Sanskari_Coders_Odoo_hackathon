# Installation
> `npm install --save @types/testing-library__jest-dom`

# Summary
This package contains type definitions for @testing-library/jest-dom (https://github.com/testing-library/jest-dom).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/testing-library__jest-dom.

### Additional Details
 * Last updated: Tue, 21 Jun 2022 18:01:50 GMT
 * Dependencies: [@types/jest](https://npmjs.com/package/@types/jest)
 * Global values: none

# Credits
These definitions were written by [Ernesto García](https://github.com/gnapse), [John Gozde](https://github.com/jgoz), [Seth Macpherson](https://github.com/smacpherson64), and [Andrew Leedham](https://github.com/AndrewLeedham).
