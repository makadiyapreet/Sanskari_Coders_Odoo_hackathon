// makes it so people can import from '@testing-library/react/pure'
module.exports = require('./dist/pure')
